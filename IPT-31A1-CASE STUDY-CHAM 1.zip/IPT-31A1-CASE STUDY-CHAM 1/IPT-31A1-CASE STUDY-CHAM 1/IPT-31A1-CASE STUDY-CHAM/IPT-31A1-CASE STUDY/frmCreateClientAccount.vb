﻿Imports System.Data.OleDb

Public Class frmCreateClientAccount
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles lblLastname.Click

    End Sub

    Private Sub frmCreateClientAccount_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call connection()
        Dim acc As New Random
        txtAccountNo.Text = acc.Next(0, 1000000000)
    End Sub

    Private Sub btnCreateAccount_Click(sender As Object, e As EventArgs) Handles btnCreateAccount.Click
        Call CheckAccounts()
    End Sub

    Private Sub SaveData()
        sql = "SELECT AccountNo FROM tblAccounts WHERE AccountNo = @AccountNo"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("[@AcountcNo]", txtAccountNo.Text)
            .Parameters.AddWithValue("[@Lastname]", txtLastname.Text)
            .Parameters.AddWithValue("[@Firstname]", txtFirstname.Text)
            .Parameters.AddWithValue("[@Middlename]", txtMiddlename.Text)
            .Parameters.AddWithValue("[@Address]", txtAddress.Text)
            .Parameters.AddWithValue("[@ContactNo]", txtContactNo.Text)
            .Parameters.AddWithValue("[@Email]", txtEmail.Text)
            .Parameters.AddWithValue("[@Age]", txtAge.Text)
            .Parameters.AddWithValue("[@BirthDate]", DateTimePicker1.Value.ToString)
            .Parameters.AddWithValue("[@Gender]", cboGender.Text)
            .Parameters.AddWithValue("[@AccStatus]", "Active")
            .ExecuteNonQuery()
        End With
        MsgBox("New Account succesfully created", MsgBoxStyle.Information, "Client Account")

    End Sub

    Private Sub SavePIN()
        If txtPIN.Text <> txtrPIN.Text Then
            MsgBox("Pin Mismatch", MsgBoxStyle.Critical, "Re-Type PIN")
        Else

            sql = "Insert Into tblPIN (AccountNo, PIN) values (@AccountNo, @PIN)"
            cmd = New OleDbCommand(sql, cn)

            With cmd
                .Parameters.AddWithValue("@AccountNo", txtAccountNo.Text)
                .Parameters.AddWithValue("@PIN", txtPIN.Text)
                .ExecuteNonQuery()
            End With
            SaveData()
        End If


    End Sub

    Private Sub CheckAccounts()
        sql = "Select AccountNo from tblAccounts where AccountNo='" & txtAccountNo.Text & "'"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader

        If dr.HasRows = True Then
            MsgBox("Account is already Exist", MsgBoxStyle.Exclamation)
        ElseIf String.IsNullOrWhiteSpace(txtFirstName.Text) OrElse String.IsNullOrWhiteSpace(txtLastName.Text) OrElse String.IsNullOrWhiteSpace(txtMiddleName.Text) OrElse String.IsNullOrWhiteSpace(txtEmail.text) OrElse String.IsNullOrWhiteSpace(txtContactNo.Text) OrElse String.IsNullOrWhiteSpace(txtage.Text) OrElse String.IsNullOrWhiteSpace(txtaddress.Text) OrElse String.IsNullOrWhiteSpace(txtPIN.Text) OrElse String.IsNullOrWhiteSpace(txtrPIN.Text) OrElse String.IsNullOrWhiteSpace(cboGender.Text) OrElse String.IsNullOrWhiteSpace(DateTimePicker1.Text) Then
            MsgBox("All fields are required!", vbCritical, "Error")
            Return
        Else

            SavePIN()

        End If

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub txtPIN_TextChanged(sender As Object, e As EventArgs) Handles txtPIN.TextChanged

    End Sub
End Class