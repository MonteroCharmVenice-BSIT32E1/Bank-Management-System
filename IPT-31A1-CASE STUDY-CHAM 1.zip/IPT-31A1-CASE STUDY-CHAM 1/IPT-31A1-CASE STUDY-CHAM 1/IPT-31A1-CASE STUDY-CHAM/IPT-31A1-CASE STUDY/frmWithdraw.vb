﻿Imports System.Data.OleDb

Public Class frmWithdraw
    Private Sub frmWithdraw_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call connection()
    End Sub

    Private Sub btnWithdraw_Click(sender As Object, e As EventArgs) Handles btnWithdraw.Click
        If Val(txtAmount.Text) < 100 Then
            MsgBox("the minimum withdraw is 100.00", MsgBoxStyle.Critical)
        Else
            saveWithdraw()
            txtAmount.Clear()
            Activitylogs("Withdraw")

        End If
    End Sub
    Private Sub saveWithdraw()
        sql = "Insert Into tblTransactions([AccountNo], [TransactionNo], [TransactionType], [Amount], [DateTime]) values ([@AccountNo], [@TransactionNo], [@TransactionType], [@Amount], [@DateTime])"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("@AccountNo", frmClientDashboards.lblAccNo.Text)
            .Parameters.AddWithValue("@TransactionNo", "1")
            .Parameters.AddWithValue("@TransactionType", "Withdraw")
            .Parameters.AddWithValue("@Amount", txtAmount.Text)
            .Parameters.AddWithValue("@DateTime", Now.ToString)
            .ExecuteNonQuery()

        End With

        'balance will be update after the withdraw transaction
        Dim withdrawalAmount As Decimal = Convert.ToDecimal(txtAmount.Text)
        Dim currentBalance As Decimal = Convert.ToDecimal(frmClientDashboards.lblCurrentBalance.Text)
        Dim newBalance As Decimal = currentBalance - withdrawalAmount

        ' update in client dashboard
        frmClientDashboards.lblCurrentBalance.Text = newBalance.ToString()


        MsgBox("Transaction Success!", MsgBoxStyle.Information)
        getAmount()



    End Sub

    Private Sub getAmount()
        ' Calculate total deposits
        sql = "SELECT SUM(Amount) FROM tblTransactions WHERE AccountNo=@AccountNo AND TransactionType='Deposit'"
        cmd = New OleDbCommand(sql, cn)
        cmd.Parameters.AddWithValue("@AccountNo", frmClientDashboards.lblAccNo.Text)
        dr = cmd.ExecuteReader
        Dim totalDeposits As Decimal = 0

        If dr.Read Then
            If Not IsDBNull(dr(0)) Then
                totalDeposits = Convert.ToDecimal(dr(0))
            End If
        End If
        dr.Close()

        ' Calculate total withdrawals
        sql = "SELECT SUM(Amount) FROM tblTransactions WHERE AccountNo=@AccountNo AND TransactionType='Withdraw'"
        cmd = New OleDbCommand(sql, cn)
        cmd.Parameters.AddWithValue("@AccountNo", frmClientDashboards.lblAccNo.Text)
        dr = cmd.ExecuteReader
        Dim totalWithdrawals As Decimal = 0

        If dr.Read Then
            If Not IsDBNull(dr(0)) Then
                totalWithdrawals = Convert.ToDecimal(dr(0))
            End If
        End If
        dr.Close()

        ' Calculate current balance
        Dim currentBalance As Decimal = totalDeposits - totalWithdrawals
        frmClientDashboards.lblCurrentBalance.Text = currentBalance.ToString()
        NewBal(currentBalance)
    End Sub

    Private Sub NewBal(balance As Decimal)
        Dim AccountNo As String
        Dim Bal As Decimal ' Adjust the data type to Decimal

        AccountNo = frmClientDashboards.lblAccNo.Text
        Bal = balance ' Assign the provided balance value

        sql = "INSERT INTO tblBalance ([AccountNo], [CBalance], [TimeStamp]) VALUES (@AccountNo, @CBalance, @TimeStamp)"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("@AccountNo", AccountNo)
            .Parameters.AddWithValue("@CBalance", Bal)
            .Parameters.AddWithValue("@TimeStamp", Now.ToString)
            .ExecuteNonQuery()
        End With
    End Sub

    Private Sub PrintReceipt()
        Dim ReceiptInfo As String = $"Receipt Details:" & vbCrLf &
                                      $"Account Number: {frmClientDashboards.lblAccNo.Text}" & vbCrLf &
                                      $"Transaction Type: Cash Withdrawal" & vbCrLf &
                                      $"Amount: {txtAmount.Text}" & vbCrLf &
                                      $"Date and Time: {Now.ToString}" & vbCrLf &
                                      $"Current Balance: {frmClientDashboards.lblCurrentBalance.Text}" & vbCrLf & vbCrLf &
                                      "Thank you for using our Bank!"
        MessageBox.Show(ReceiptInfo, "Receipt", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
    Private Sub LoadAccounts()
        ' Assuming lblAccNo.Text contains the account number
        sql = "SELECT * FROM tblTransaction WHERE AccountNo=@AccountNo order by TransactionID desc"
        cmd = New OleDbCommand(sql, cn)
        cmd.Parameters.AddWithValue("@AccountNo", frmClientDashboards.lblAccNo.Text)
        dr = cmd.ExecuteReader

        frmClientDashboards.ListView1.Items.Clear()
        While dr.Read()
            Dim x As New ListViewItem(dr("TransactionID").ToString())
            x.SubItems.Add(dr("TransactionType").ToString())
            x.SubItems.Add(dr("Amount").ToString())
            x.SubItems.Add(dr("DateTime").ToString())
            frmClientDashboards.ListView1.Items.Add(x)
        End While
        'dr.Close()
    End Sub
End Class