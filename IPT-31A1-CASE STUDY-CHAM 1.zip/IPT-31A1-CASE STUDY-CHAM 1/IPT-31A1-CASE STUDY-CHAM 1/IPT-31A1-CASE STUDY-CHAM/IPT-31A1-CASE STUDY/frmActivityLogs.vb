﻿Imports System.Data.OleDb

Module frmActivityLogs

    Public Sub Activitylogs(action As String)
        Call connection()
        Dim timestamp As String = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        Dim AccountNo As String = frmClientDashboards.lblAccNo.Text

        sql = "INSERT INTO tblActivityLogs ([AccountNo], [Activity], [TimeStamp]) values (@AccountNo, @Activity, @TimeStamp)"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("@AccountNo", AccountNo)
            .Parameters.AddWithValue("@Activity", action)
            .Parameters.AddWithValue("@TimeStamp", timestamp)
            .ExecuteNonQuery()


        End With



    End Sub

End Module
