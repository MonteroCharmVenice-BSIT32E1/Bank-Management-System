﻿Imports System.Data.OleDb
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class frmClientDashboards

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles BtnExit.Click
        If MsgBox("Do you want to Logout?", vbQuestion + vbYesNo) = vbYes Then
            MsgBox("Thank you for using the Bank Management System...")
            Activitylogs("Logged Out")
            Me.Close()
            frmDeposit.Hide()

        End If
    End Sub

    Private Sub frmClientDashboards_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call connection()

        Call getAmount()
        LoadAccounts()



    End Sub

    Private Sub btnDeposit_Click(sender As Object, e As EventArgs) Handles btnDeposit.Click
        frmDeposit.Show()


    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lblDate.Text = Now.ToLongDateString & " " & Now.ToLongTimeString
    End Sub

    Private Sub getAmount()
        ' Calculate total deposits
        sql = "SELECT SUM(Amount) FROM tblTransactions WHERE AccountNo=@AccountNo AND TransactionType='Deposit'"
        cmd = New OleDbCommand(sql, cn)
        cmd.Parameters.AddWithValue("@AccountNo", lblAccNo.Text)
        dr = cmd.ExecuteReader
        Dim totalDeposits As Decimal = 0

        If dr.Read Then
            If Not IsDBNull(dr(0)) Then
                totalDeposits = Convert.ToDecimal(dr(0))
            End If
        End If
        dr.Close()

        ' Calculate total withdrawals
        sql = "SELECT SUM(Amount) FROM tblTransactions WHERE AccountNo=@AccountNo AND TransactionType='Withdraw'"
        cmd = New OleDbCommand(sql, cn)
        cmd.Parameters.AddWithValue("@AccountNo", lblAccNo.Text)
        dr = cmd.ExecuteReader
        Dim totalWithdrawals As Decimal = 0

        If dr.Read Then
            If Not IsDBNull(dr(0)) Then
                totalWithdrawals = Convert.ToDecimal(dr(0))
            End If
        End If
        dr.Close()

        ' Display total deposits and withdrawals for reference (optional)
        ''   lblTotalDeposits.Text = totalDeposits.ToString()
        '' lblTotalWithdrawals.Text = totalWithdrawals.ToString()

        ' Calculate current balance
        Dim currentBalance As Decimal = totalDeposits - totalWithdrawals
        lblCurrentBalance.Text = currentBalance.ToString()

        ' Update the balance in the database (if desired)
        NewBal(currentBalance)
        LoadAccounts()

    End Sub

    Private Sub AMOUNT()
        sql = "SELECT sum(Amount) FROM tblTransactions where AccountNo=@AccountNo and TransactionType=@TransactionType"
        cmd = New OleDbCommand(sql, cn)
        cmd.Parameters.AddWithValue("[@AccountNo]", lblAccNo.Text)
        cmd.Parameters.AddWithValue("[@TransactionType]", "Deposit")
        dr = cmd.ExecuteReader
        If dr.Read = True Then
            lblCurrentBalance.Text = dr(0).ToString
        End If
    End Sub


    Private Sub btnWithdraw_Click(sender As Object, e As EventArgs) Handles btnWithdraw.Click
        frmWithdraw.Show()
    End Sub

    Private Sub btnChangePIN_Click(sender As Object, e As EventArgs) Handles btnChangePIN.Click
        frmChangePIN.Show()


    End Sub

    Private Sub NewBal(balance As Decimal)
        Dim AccNum As String
        Dim Bal As Decimal ' Adjust the data type to Decimal

        AccNum = lblAccNo.Text
        Bal = balance ' Assign the provided balance value

        sql = "INSERT INTO tblBalance ([AccountNo], [CBalance], [TimeStamp]) VALUES (@AccountNo, @CBalance, @TimeStamp)"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("@AccountNo", AccNum)
            .Parameters.AddWithValue("@CBalance", Bal)
            .Parameters.AddWithValue("@TimeStamp", Now.ToString)
            .ExecuteNonQuery()
        End With
    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged

    End Sub

    Private Sub LoadAccounts()

        sql = "SELECT * FROM tblTransactions WHERE AccountNo=@AccountNo order by TransactionID desc"
        cmd = New OleDbCommand(sql, cn)
        cmd.Parameters.AddWithValue("@AccNo", lblAccNo.Text)
        dr = cmd.ExecuteReader

        ListView1.Items.Clear()
        While dr.Read()
            Dim x As New ListViewItem(dr("TransactionID").ToString())
            x.SubItems.Add(dr("TransactionType").ToString())
            x.SubItems.Add(dr("Amount").ToString())
            x.SubItems.Add(dr("DateTime").ToString())
            ListView1.Items.Add(x)
        End While

    End Sub

    Private Sub btnActLogs_Click(sender As Object, e As EventArgs) Handles btnActLogs.Click
        frmActivityLog.Show()


    End Sub

    Private Sub GroupBox3_Enter(sender As Object, e As EventArgs) Handles GroupBox3.Enter

    End Sub
End Class