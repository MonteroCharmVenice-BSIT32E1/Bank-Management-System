﻿Imports System.Data.OleDb

Public Class frmActivityLog
    Private Sub frmActivityLog_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call connection()
        LoadAccounts()
    End Sub

    Private Sub LoadAccounts()
        sql = "SELECT * from tblActivityLogs WHERE AccountNo=@AccountNo order by LogID desc"
        cmd = New OleDbCommand(sql, cn)
        cmd.Parameters.AddWithValue("@AccountNo", frmClientDashboards.lblAccNo.Text)
        dr = cmd.ExecuteReader


        ListView1.Items.Clear()
        While dr.Read()
            Dim x As New ListViewItem(dr("Activity").ToString())
            x.SubItems.Add(dr("TimeStamp").ToString())
            ListView1.Items.Add(x)
        End While
        'dr.Close()

    End Sub
End Class