﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCreateAccount
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCreateAccount))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblusername = New System.Windows.Forms.Label()
        Me.lblpassword = New System.Windows.Forms.Label()
        Me.lblcpassword = New System.Windows.Forms.Label()
        Me.lblrole = New System.Windows.Forms.Label()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.txtusername = New System.Windows.Forms.TextBox()
        Me.txtpassword = New System.Windows.Forms.TextBox()
        Me.txtcpassword = New System.Windows.Forms.TextBox()
        Me.cborole = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Impact", 25.81132!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(250, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(277, 46)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "CREATE ACCOUNT"
        '
        'lblusername
        '
        Me.lblusername.AutoSize = True
        Me.lblusername.BackColor = System.Drawing.Color.Transparent
        Me.lblusername.Font = New System.Drawing.Font("Javanese Text", 12.22642!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblusername.Location = New System.Drawing.Point(112, 176)
        Me.lblusername.Name = "lblusername"
        Me.lblusername.Size = New System.Drawing.Size(105, 41)
        Me.lblusername.TabIndex = 1
        Me.lblusername.Text = "Username"
        '
        'lblpassword
        '
        Me.lblpassword.AutoSize = True
        Me.lblpassword.BackColor = System.Drawing.Color.Transparent
        Me.lblpassword.Font = New System.Drawing.Font("Javanese Text", 10.86792!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpassword.Location = New System.Drawing.Point(113, 223)
        Me.lblpassword.Name = "lblpassword"
        Me.lblpassword.Size = New System.Drawing.Size(89, 36)
        Me.lblpassword.TabIndex = 2
        Me.lblpassword.Text = "Password"
        '
        'lblcpassword
        '
        Me.lblcpassword.AutoSize = True
        Me.lblcpassword.BackColor = System.Drawing.Color.Transparent
        Me.lblcpassword.Font = New System.Drawing.Font("Javanese Text", 12.22642!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcpassword.Location = New System.Drawing.Point(112, 259)
        Me.lblcpassword.Name = "lblcpassword"
        Me.lblcpassword.Size = New System.Drawing.Size(175, 41)
        Me.lblcpassword.TabIndex = 3
        Me.lblcpassword.Text = "Confirm Password"
        '
        'lblrole
        '
        Me.lblrole.AutoSize = True
        Me.lblrole.BackColor = System.Drawing.Color.Transparent
        Me.lblrole.Font = New System.Drawing.Font("Javanese Text", 12.22642!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblrole.Location = New System.Drawing.Point(112, 296)
        Me.lblrole.Name = "lblrole"
        Me.lblrole.Size = New System.Drawing.Size(57, 41)
        Me.lblrole.TabIndex = 4
        Me.lblrole.Text = "Role"
        '
        'btnsave
        '
        Me.btnsave.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnsave.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnsave.Font = New System.Drawing.Font("Impact", 10.18868!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.ForeColor = System.Drawing.SystemColors.MenuText
        Me.btnsave.Location = New System.Drawing.Point(221, 478)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(75, 30)
        Me.btnsave.TabIndex = 5
        Me.btnsave.Text = "Save"
        Me.btnsave.UseVisualStyleBackColor = False
        '
        'btnclear
        '
        Me.btnclear.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnclear.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnclear.Font = New System.Drawing.Font("Impact", 10.18868!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclear.ForeColor = System.Drawing.SystemColors.MenuText
        Me.btnclear.Location = New System.Drawing.Point(360, 478)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(75, 30)
        Me.btnclear.TabIndex = 6
        Me.btnclear.Text = "Clear"
        Me.btnclear.UseVisualStyleBackColor = False
        '
        'txtusername
        '
        Me.txtusername.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.txtusername.Location = New System.Drawing.Point(307, 185)
        Me.txtusername.Name = "txtusername"
        Me.txtusername.Size = New System.Drawing.Size(189, 20)
        Me.txtusername.TabIndex = 7
        '
        'txtpassword
        '
        Me.txtpassword.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.txtpassword.Location = New System.Drawing.Point(307, 223)
        Me.txtpassword.Name = "txtpassword"
        Me.txtpassword.Size = New System.Drawing.Size(189, 20)
        Me.txtpassword.TabIndex = 8
        '
        'txtcpassword
        '
        Me.txtcpassword.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.txtcpassword.Location = New System.Drawing.Point(307, 262)
        Me.txtcpassword.Name = "txtcpassword"
        Me.txtcpassword.Size = New System.Drawing.Size(189, 20)
        Me.txtcpassword.TabIndex = 9
        '
        'cborole
        '
        Me.cborole.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.cborole.FormattingEnabled = True
        Me.cborole.Items.AddRange(New Object() {"Admin", "User"})
        Me.cborole.Location = New System.Drawing.Point(307, 308)
        Me.cborole.Name = "cborole"
        Me.cborole.Size = New System.Drawing.Size(189, 21)
        Me.cborole.TabIndex = 10
        '
        'frmCreateAccount
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(797, 596)
        Me.Controls.Add(Me.cborole)
        Me.Controls.Add(Me.txtcpassword)
        Me.Controls.Add(Me.txtpassword)
        Me.Controls.Add(Me.txtusername)
        Me.Controls.Add(Me.btnclear)
        Me.Controls.Add(Me.btnsave)
        Me.Controls.Add(Me.lblrole)
        Me.Controls.Add(Me.lblcpassword)
        Me.Controls.Add(Me.lblpassword)
        Me.Controls.Add(Me.lblusername)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmCreateAccount"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents lblusername As Label
    Friend WithEvents lblpassword As Label
    Friend WithEvents lblcpassword As Label
    Friend WithEvents lblrole As Label
    Friend WithEvents btnsave As Button
    Friend WithEvents btnclear As Button
    Friend WithEvents txtusername As TextBox
    Friend WithEvents txtpassword As TextBox
    Friend WithEvents txtcpassword As TextBox
    Friend WithEvents cborole As ComboBox
End Class
