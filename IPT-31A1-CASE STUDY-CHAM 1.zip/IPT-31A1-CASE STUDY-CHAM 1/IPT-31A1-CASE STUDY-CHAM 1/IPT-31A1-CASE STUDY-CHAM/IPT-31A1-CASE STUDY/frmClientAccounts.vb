﻿Imports System.Data.OleDb

Public Class frmClientAccounts
    Private Sub frmClientAccounts_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call connection()
        Call LoadAccounts()
        Dim Acc As New Random
        txtAccountNo.Text = Acc.Next(0, 1000000000)

    End Sub

    Private Sub LoadAccounts()
        sql = "Select * from qryAccounts"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        Dim x As ListViewItem
        ListView1.Items.Clear()
        Do While dr.Read = True
            x = New ListViewItem(dr("AccountNo").ToString)
            x.SubItems.Add(dr("Lastname").ToString & " " & dr("Firstname").ToString)
            x.SubItems.Add(dr("Address").ToString)
            x.SubItems.Add(dr("ContactNo").ToString)
            x.SubItems.Add(dr("Email").ToString)
            x.SubItems.Add(dr("Age").ToString)
            x.SubItems.Add(dr("BirthDate").ToString)
            x.SubItems.Add(dr("Gender").ToString)
            x.SubItems.Add(dr("PIN").ToString)
            x.SubItems.Add(dr("AccountStatus").ToString)
            ListView1.Items.Add(x)

        Loop
    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
        If ListView1.SelectedItems.Count > 0 Then
            txtAccountNo.Text = ListView1.SelectedItems(0).SubItems(0).Text
        End If
    End Sub
    'retrieval from database
    Private Sub txtAccountNo_TextChanged(sender As Object, e As EventArgs) Handles txtAccountNo.TextChanged
        sql = "Select Lastname, Firstname, Middlename, Address, ContactNo, Email, Age, BirthDate, Gender, PIN, AccountStatus from qryAccounts where AccountNo='" & txtAccountNo.Text & "'"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        If dr.Read = True Then
            txtLastname.Text = dr("Lastname").ToString
            txtFirstname.Text = dr("Firstname").ToString
            txtMiddlename.Text = dr("Middlename").ToString
            txtAddress.Text = dr("Address").ToString
            txtContactNo.Text = dr("ContactNo").ToString
            txtEmail.Text = dr("Email").ToString
            txtAge.Text = dr("Age").ToString
            DateTimePicker1.Value = dr("BirthDate").ToString
            cboGender.Text = dr("Gender").ToString
            txtPIN.Text = dr("PIN").ToString
            cboAccountStatus.Text = dr("AccountStatus").ToString
        End If
    End Sub
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If txtPIN.Text <> txtrPIN.Text Then
            MsgBox("PIN and Re-PIN mismatched", MsgBoxStyle.Critical)
        ElseIf txtPIN.Text < 6 Or txtrPIN.Text < 6 Then
            MsgBox("PIN must be atleast 6 characters above", MsgBoxStyle.Exclamation)
        Else
            UpdateData()

        End If
    End Sub

    Private Sub UpdateData()
        ' MsgBox("Upated")
        sql = "UPDATE tblAccounts set Lastname=@Lastname, Firstname=@Firstname, Middlename=@Middlename, Address=@Address, ContactNo=@ContactNo, Email=@Email, Age=@Age, BirthDate=@BirthDate, Gender=@Gender, AccountStatus=@AccountStatus where AccountNo=@AccountNo "
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("@Lastname", txtLastname.Text)
            .Parameters.AddWithValue("@Firstname", txtFirstname.Text)
            .Parameters.AddWithValue("@Middlename", txtMiddlename.Text)
            .Parameters.AddWithValue("@Address", txtAddress.Text)
            .Parameters.AddWithValue("@ContactNo", txtContactNo.Text)
            .Parameters.AddWithValue("@Email", txtEmail.Text)
            .Parameters.AddWithValue("@Age", txtAge.Text)
            .Parameters.AddWithValue("@BirthDate", DateTimePicker1.Text)
            .Parameters.AddWithValue("@Gender", cboGender.Text)
            .Parameters.AddWithValue("@AccountStatus", cboAccountStatus.Text)
            .Parameters.AddWithValue("@AccountNo", txtAccountNo.Text)
            .ExecuteNonQuery()

        End With
        UpdatePIN()

        MsgBox("Client record successfully updated", MsgBoxStyle.Information)
        LoadAccounts()

    End Sub

    Private Sub UpdatePIN()
        sql = "UPDATE tblPIN set PIN=@PIN where AccountNo=@AccountNo"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("@PIN", txtPIN.Text)
            .Parameters.AddWithValue("@AccountNo", txtAccountNo.Text)
            .ExecuteNonQuery()

        End With
    End Sub

    Private Sub SaveData()
        sql = "Insert Into tblAccounts([AccountNo], [Lastname], [Firstname], [Middlename], [Address], [ContactNo], [Email], [Age], [BirthDate], [Gender], [AccountStatus]) values([@AccountNo], [@Lastname], [@Firstname], [@Middlename], [@Address], [@ContactNo], [@Email], [@Age], [@BirthDate], [@Gender], [@AccountStatus])"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("[@AccountNo]", txtAccountNo.Text)
            .Parameters.AddWithValue("[@Lastname]", txtLastname.Text)
            .Parameters.AddWithValue("[@Firstname]", txtFirstname.Text)
            .Parameters.AddWithValue("[@Middlename]", txtMiddlename.Text)
            .Parameters.AddWithValue("[@Address]", txtAddress.Text)
            .Parameters.AddWithValue("[@ContactNo]", txtContactNo.Text)
            .Parameters.AddWithValue("[@Email]", txtEmail.Text)
            .Parameters.AddWithValue("[@Age]", txtAge.Text)
            .Parameters.AddWithValue("[@BirthDate]", DateTimePicker1.Value.ToString)
            .Parameters.AddWithValue("[@Gender]", cboGender.Text)
            .Parameters.AddWithValue("[@AccountStatus]", cboAccountStatus.Text)
            .ExecuteNonQuery()
        End With

        MsgBox("New Account succesfully created", MsgBoxStyle.Information, "Client Account")

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        CheckAccounts()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        frmAdminDashboard.Show()

    End Sub

    Private Sub cboGender_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboGender.SelectedIndexChanged

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
    Private Sub SavePIN()
        If txtPIN.Text <> txtrPIN.Text Then
            MsgBox("Pin Mismatch", MsgBoxStyle.Critical, "Re-Type PIN")
        Else

            sql = "Insert Into tblPIN (AccountNo, PIN) values (@AccountNo, @PIN)"
            cmd = New OleDbCommand(sql, cn)

            With cmd
                .Parameters.AddWithValue("@AccountNo", txtAccountNo.Text)
                .Parameters.AddWithValue("@PIN", txtPIN.Text)
                .ExecuteNonQuery()
            End With
            SaveData()
        End If


    End Sub
    Private Sub CheckAccounts()
        sql = "Select AccNo from tblAccounts where AccNo='" & txtAccountNo.Text & "'"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader

        If dr.HasRows = True Then
            MsgBox("Account is already Exist", MsgBoxStyle.Exclamation)

        ElseIf String.IsNullOrWhiteSpace(txtFirstname.Text) OrElse String.IsNullOrWhiteSpace(txtLastname.Text) OrElse String.IsNullOrWhiteSpace(txtMiddlename.Text) OrElse String.IsNullOrWhiteSpace(txtEmail.Text) OrElse String.IsNullOrWhiteSpace(txtContactNo.Text) OrElse String.IsNullOrWhiteSpace(txtAge.Text) OrElse String.IsNullOrWhiteSpace(txtAddress.Text) OrElse String.IsNullOrWhiteSpace(txtPIN.Text) OrElse String.IsNullOrWhiteSpace(txtrPIN.Text) OrElse String.IsNullOrWhiteSpace(cboGender.Text) OrElse String.IsNullOrWhiteSpace(DateTimePicker1.Text) Then
            MsgBox("All fields are required!", vbCritical, "Error")
            Return
        Else

            SavePIN()

        End If

    End Sub
End Class