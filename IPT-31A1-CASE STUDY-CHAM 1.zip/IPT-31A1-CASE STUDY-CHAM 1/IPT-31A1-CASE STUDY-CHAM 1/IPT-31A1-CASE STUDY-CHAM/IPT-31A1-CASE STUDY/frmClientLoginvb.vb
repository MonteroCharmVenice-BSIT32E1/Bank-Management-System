﻿Imports System.Data.OleDb

Public Class frmClientLoginvb
    Private Sub frmClientLoginvb_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call connection()
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        frmCreateClientAccount.ShowDialog()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        sql = "Select * from qryAccounts where AccountNo='" & txtAccountNo.Text & "' and PIN='" & txtPIN.Text & "' and AccountStatus='Active'"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader

        If dr.Read = True Then
            frmClientDashboards.lblAccNo.Text = dr("AccountNo").ToString
            frmClientDashboards.lblAccName.Text = "Mr./Mrs." & dr("FirstName").ToString & " " & dr("Lastname").ToString
            MsgBox("Login in Sucess", MsgBoxStyle.Information)
            Activitylogs("Logged In")
            frmClientDashboards.Show()
            Me.Hide()




        Else

            MsgBox("Login in Failed", MsgBoxStyle.Critical)

            lblcountdownattempt.Text = lblcountdownattempt.Text - 1

            If lblcountdownattempt.Text = "0" Then

                MsgBox("You reached the maximum attempt limits", MsgBoxStyle.Critical)

                Call DisabledAccount()

                btnLogin.Enabled = False

            End If

        End If



    End Sub

    Private Sub DisabledAccount()
        sql = "Update tblAccounts SET AccountStatus = @AccountStatus where AccountNo = @AccountNo"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("@AccountStatus", "Disable")
            .Parameters.AddWithValue("@AccountNo", txtAccountNo.Text)
            .ExecuteNonQuery()

        End With

        MsgBox("You're Account is disabled, contact the nearest branch to activate your account", MsgBoxStyle.Exclamation)
    End Sub
    Private Sub CheckIfDisabled()
        sql = "Select AccStatus from qryAccounts where AccountNo = '" & txtAccountNo.Text & "'"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader

        If dr.HasRows = True Then
            MsgBox("This Account is disabled", MsgBoxStyle.Critical)
        Else

            If lblAccountNo.Text = "0" Then
                MsgBox("You reached the maximum attempt limits", MsgBoxStyle.Critical)
                Call DisabledAccount()
                btnLogin.Enabled = False
            End If
        End If

    End Sub

    Private Sub lblAttempts_Click(sender As Object, e As EventArgs) Handles lblcountdownattempt.Click

    End Sub

    Private Sub lbl1_Click(sender As Object, e As EventArgs) Handles lbl1.Click

    End Sub

    Private Sub lblExit_Click(sender As Object, e As EventArgs) Handles lblExit.Click
        Me.Close()
    End Sub
End Class