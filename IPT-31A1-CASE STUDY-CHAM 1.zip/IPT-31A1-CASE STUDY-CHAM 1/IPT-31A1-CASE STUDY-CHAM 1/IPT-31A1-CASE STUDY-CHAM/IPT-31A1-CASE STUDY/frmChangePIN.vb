﻿Imports System.Data.OleDb

Public Class frmChangePIN
    Private Sub frmCangePIN_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call connection()
    End Sub

    Private Sub clear()
        txtNewPIN.Clear()
        txtOldPIN.Clear()
        txtrnewPIN.Clear()
    End Sub

    Private Sub btnSavePIN_Click(sender As Object, e As EventArgs) Handles btnSavePIN.Click
        If txtNewPIN.Text <> txtrnewPIN.Text Then
            MsgBox("New PIN and Re-type PIN mismatch!!", MsgBoxStyle.Critical)
        ElseIf txtNewPIN.Text = txtOldPIN.Text Then
            MsgBox("You use an old PIN!!", MsgBoxStyle.Critical)
        Else
            CheckOldPIN()
            Activitylogs("Change Pin")

        End If
    End Sub

    Private Sub SaveNewPIN()
        sql = "UPDATE tblPIN SET [PIN] = @PIN WHERE AccountNo = @AccountNo"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("@PIN", txtNewPIN.Text)
            .Parameters.AddWithValue("@AccountNo", frmClientDashboards.lblAccNo.Text)
            .ExecuteNonQuery()
        End With

        MsgBox("You succesfully changed your PIN!!", MsgBoxStyle.Information)
        Activitylogs("Change PIN")

    End Sub

    Private Sub CheckOldPIN()
        sql = "Select * from tblPIN where PIN='" & txtOldPIN.Text & "'"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader

        If dr.Read = True Then
            SaveNewPIN()
        Else
            MsgBox("Wrong PIN!! Please Try Again!!", MsgBoxStyle.Critical)
        End If
    End Sub

    Private Sub txtOldPIN_TextChanged(sender As Object, e As EventArgs) Handles txtOldPIN.TextChanged

    End Sub
End Class