﻿Imports System.Data.OleDb

Public Class frmCreateAccount

    Private Sub frmCreateAccount_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call connection()
    End Sub

    Private Sub SaveData()
        sql = "Insert Into tblUsers([username], [password], [role]) values([@username], [@password], [@role])"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("[@username]", txtusername.Text)
            .Parameters.AddWithValue("[@password]", txtpassword.Text)
            .Parameters.AddWithValue("[@role]", cborole.Text)
            .ExecuteNonQuery()
        End With

        MsgBox("New Record Successfully Save", MsgBoxStyle.Information, "Save Data")

    End Sub

    Private Sub CheckIfUsernameExist()
        sql = "Select Username from tblUsers where username='" & txtusername.Text & "'"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        If dr.HasRows = True Then
            MsgBox("Username already exists", MsgBoxStyle.Information, "Duplicate Records")

        ElseIf MsgBox("Are sure you that all credentials are correct?", vbQuestion + vbYesNo, "Create Account") = vbYes Then
            SaveData()
            clear()

        End If
    End Sub
    Public Sub clear()
        txtcpassword.Clear()
        txtpassword.Clear()
        txtusername.Clear()
        cborole.Text = ""

    End Sub

    Private Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        If txtpassword.Text <> txtcpassword.Text Then
            MsgBox("Password and Confirmed Password Mismatch", MsgBoxStyle.Critical)

        ElseIf txtpassword.TextLength < 6 And txtcpassword.TextLength < 6 Then
            MsgBox("Password must have more than 6 characters", MsgBoxStyle.Critical)
        Else
            Call CheckIfUsernameExist()
        End If
    End Sub
End Class