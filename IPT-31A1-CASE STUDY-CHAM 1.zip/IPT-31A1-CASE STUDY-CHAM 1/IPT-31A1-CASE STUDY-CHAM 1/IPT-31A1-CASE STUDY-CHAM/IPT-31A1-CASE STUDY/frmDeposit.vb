﻿Imports System.Data.OleDb

Public Class frmDeposit
    Private Sub frmDeposit_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call connection()
    End Sub

    Private Sub btnDeposit_Click(sender As Object, e As EventArgs) Handles btnDeposit.Click
        If Val(txtAmount.Text) < 100 Then
            MsgBox("The minimum deposit is 100.00", MsgBoxStyle.Critical)
        Else
            saveDeposit()
            Activitylogs("Deposit")

        End If
    End Sub

    Private Sub saveDeposit()
        sql = "Insert Into tblTransactions([AccountNo], [TransactionNo], [TransactionType], [Amount], [DateTime]) values ([@AccountNo], [@TransactionNo], [@TransactionType], [@Amount], [@DateTime])"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("@AccountNo", frmClientDashboards.lblAccNo.Text)
            .Parameters.AddWithValue("@TransactionNo", "1")
            .Parameters.AddWithValue("@TransactionType", "Deposit")
            .Parameters.AddWithValue("@Amount", txtAmount.Text)
            .Parameters.AddWithValue("@DateTime", Now.ToString)
            .ExecuteNonQuery()

        End With

        MsgBox("Transaction Success!", MsgBoxStyle.Information)
        Call getAmount()

    End Sub

    Private Sub getAmount()
        ' Calculate total deposits
        sql = "SELECT SUM(Amount) FROM tblTransactions WHERE AccountNo=@AccountNo AND TransactionType='Deposit'"
        cmd = New OleDbCommand(sql, cn)
        cmd.Parameters.AddWithValue("@AccountNo", frmClientDashboards.lblAccNo.Text)
        dr = cmd.ExecuteReader
        Dim totalDeposits As Decimal = 0

        If dr.Read Then
            If Not IsDBNull(dr(0)) Then
                totalDeposits = Convert.ToDecimal(dr(0))
            End If
        End If
        dr.Close()

        ' Calculate total withdrawals
        sql = "SELECT SUM(Amount) FROM tblTransactions WHERE AccountNo=@AccountNo AND TransactionType='Withdraw'"
        cmd = New OleDbCommand(sql, cn)
        cmd.Parameters.AddWithValue("@AccountNo", frmClientDashboards.lblAccNo.Text)
        dr = cmd.ExecuteReader
        Dim totalWithdrawals As Decimal = 0

        If dr.Read Then
            If Not IsDBNull(dr(0)) Then
                totalWithdrawals = Convert.ToDecimal(dr(0))
            End If
        End If
        dr.Close()


        Dim currentBalance As Decimal = totalDeposits - totalWithdrawals
        frmClientDashboards.lblCurrentBalance.Text = currentBalance.ToString()


        NewBal(currentBalance)
    End Sub

    Private Sub NewBal(balance As Decimal)
        Dim AccNum As String
        Dim Bal As Decimal

        AccNum = frmClientDashboards.lblAccNo.Text
        Bal = balance

        sql = "INSERT INTO tblBalance ([AccountNo], [CBalance], [TimeStamp]) VALUES (@AccountNo, @CBalance, @TimeStamp)"
        cmd = New OleDbCommand(sql, cn)
        With cmd
            .Parameters.AddWithValue("@AccountNo", AccNum)
            .Parameters.AddWithValue("@CBalance", Bal)
            .Parameters.AddWithValue("@TimeStamp", Now.ToString)
            .ExecuteNonQuery()
        End With
    End Sub
End Class