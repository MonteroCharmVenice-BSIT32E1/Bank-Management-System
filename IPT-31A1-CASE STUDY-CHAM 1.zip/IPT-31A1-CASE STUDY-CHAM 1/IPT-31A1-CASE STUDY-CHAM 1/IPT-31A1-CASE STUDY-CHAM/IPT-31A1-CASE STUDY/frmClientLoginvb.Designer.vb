﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmClientLoginvb
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmClientLoginvb))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblAccountNo = New System.Windows.Forms.Label()
        Me.lblPIN = New System.Windows.Forms.Label()
        Me.txtAccountNo = New System.Windows.Forms.TextBox()
        Me.txtPIN = New System.Windows.Forms.TextBox()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.lblcountdownattempt = New System.Windows.Forms.Label()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.lblExit = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Impact", 21.73585!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(321, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(180, 39)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "CLIENT LOGIN"
        '
        'lblAccountNo
        '
        Me.lblAccountNo.AutoSize = True
        Me.lblAccountNo.BackColor = System.Drawing.Color.Transparent
        Me.lblAccountNo.Font = New System.Drawing.Font("Javanese Text", 10.86792!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAccountNo.Location = New System.Drawing.Point(70, 131)
        Me.lblAccountNo.Name = "lblAccountNo"
        Me.lblAccountNo.Size = New System.Drawing.Size(147, 36)
        Me.lblAccountNo.TabIndex = 1
        Me.lblAccountNo.Text = "Account Number"
        '
        'lblPIN
        '
        Me.lblPIN.AutoSize = True
        Me.lblPIN.BackColor = System.Drawing.Color.Transparent
        Me.lblPIN.Font = New System.Drawing.Font("Javanese Text", 10.86792!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPIN.Location = New System.Drawing.Point(70, 184)
        Me.lblPIN.Name = "lblPIN"
        Me.lblPIN.Size = New System.Drawing.Size(46, 36)
        Me.lblPIN.TabIndex = 2
        Me.lblPIN.Text = "PIN"
        '
        'txtAccountNo
        '
        Me.txtAccountNo.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.txtAccountNo.Location = New System.Drawing.Point(250, 137)
        Me.txtAccountNo.Name = "txtAccountNo"
        Me.txtAccountNo.Size = New System.Drawing.Size(239, 20)
        Me.txtAccountNo.TabIndex = 3
        '
        'txtPIN
        '
        Me.txtPIN.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.txtPIN.Location = New System.Drawing.Point(250, 184)
        Me.txtPIN.Name = "txtPIN"
        Me.txtPIN.Size = New System.Drawing.Size(239, 20)
        Me.txtPIN.TabIndex = 4
        '
        'btnLogin
        '
        Me.btnLogin.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnLogin.Location = New System.Drawing.Point(173, 490)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(75, 23)
        Me.btnLogin.TabIndex = 5
        Me.btnLogin.Text = "LOGIN"
        Me.btnLogin.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.LightSteelBlue
        Me.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnExit.Location = New System.Drawing.Point(337, 490)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "EXIT"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.BackColor = System.Drawing.Color.Transparent
        Me.lbl1.Font = New System.Drawing.Font("Javanese Text", 10.86792!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1.Location = New System.Drawing.Point(70, 236)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(82, 36)
        Me.lbl1.TabIndex = 7
        Me.lbl1.Text = "Attemps"
        '
        'lblcountdownattempt
        '
        Me.lblcountdownattempt.AutoSize = True
        Me.lblcountdownattempt.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.lblcountdownattempt.Location = New System.Drawing.Point(258, 245)
        Me.lblcountdownattempt.Name = "lblcountdownattempt"
        Me.lblcountdownattempt.Size = New System.Drawing.Size(13, 13)
        Me.lblcountdownattempt.TabIndex = 8
        Me.lblcountdownattempt.Text = "3"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.18868!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel2.Location = New System.Drawing.Point(666, 509)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(190, 18)
        Me.LinkLabel2.TabIndex = 9
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "No Account yet? Click Here"
        '
        'lblExit
        '
        Me.lblExit.AutoSize = True
        Me.lblExit.BackColor = System.Drawing.Color.IndianRed
        Me.lblExit.Font = New System.Drawing.Font("Impact", 16.30189!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblExit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblExit.Location = New System.Drawing.Point(841, -3)
        Me.lblExit.Name = "lblExit"
        Me.lblExit.Size = New System.Drawing.Size(26, 32)
        Me.lblExit.TabIndex = 10
        Me.lblExit.Text = "X"
        '
        'frmClientLoginvb
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(868, 536)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblExit)
        Me.Controls.Add(Me.LinkLabel2)
        Me.Controls.Add(Me.lblcountdownattempt)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnLogin)
        Me.Controls.Add(Me.txtPIN)
        Me.Controls.Add(Me.txtAccountNo)
        Me.Controls.Add(Me.lblPIN)
        Me.Controls.Add(Me.lblAccountNo)
        Me.Controls.Add(Me.Label1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmClientLoginvb"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents lblAccountNo As Label
    Friend WithEvents lblPIN As Label
    Friend WithEvents txtAccountNo As TextBox
    Friend WithEvents txtPIN As TextBox
    Friend WithEvents btnLogin As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lbl1 As Label
    Friend WithEvents lblcountdownattempt As Label
    Friend WithEvents LinkLabel2 As LinkLabel
    Friend WithEvents lblExit As Label
End Class
