﻿Imports System.Data.OleDb

Public Class frmLogin
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call connection()
    End Sub

    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        Try
            sql = "Select * from  tblUsers  where Username='" & txtusername.Text & "' and Password='" & txtpassword.Text & "'"
            cmd = New OleDb.OleDbCommand(sql, cn)
            dr = cmd.ExecuteReader
            If dr.Read = True Then
                MsgBox("Log in success", MsgBoxStyle.Information)
                frmAdminDashboard.tssusername.Text = txtusername.Text
                frmAdminDashboard.tssposition.Text = lblPosition.Text
                Activitylogs("lOGIN")
                frmAdminDashboard.Show()
                Me.Hide()
            Else
                MsgBox("Log in failed", MsgBoxStyle.Critical)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        frmCreateAccount.ShowDialog()
    End Sub

    Private Sub btnexit_Click(sender As Object, e As EventArgs) Handles btnexit.Click
        Me.Close()
    End Sub
    Private Sub clear()
        txtpassword.Clear()
        txtusername.Clear()
    End Sub

    Private Sub txtusername_TextChanged(sender As Object, e As EventArgs) Handles txtusername.TextChanged
        sql = "Select [Position] from tblUsers where Username= '" & txtusername.Text & "'"
        cmd = New OleDbCommand(sql, cn)
        dr = cmd.ExecuteReader
        If dr.Read = True Then
            lblPosition.Text = dr(0).ToString

        End If
    End Sub
End Class
