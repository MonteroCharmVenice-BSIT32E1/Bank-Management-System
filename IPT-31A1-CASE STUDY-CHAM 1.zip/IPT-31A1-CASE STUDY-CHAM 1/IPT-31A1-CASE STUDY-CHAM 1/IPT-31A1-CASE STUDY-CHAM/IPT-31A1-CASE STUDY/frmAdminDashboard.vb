﻿Public Class frmAdminDashboard
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        TssDate.Text = Now.ToLongDateString & " " & Now.ToLongTimeString

    End Sub
    Private Sub ClientAccountsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClientAccountsToolStripMenuItem.Click
        frmClientAccounts.ShowDialog()
    End Sub
End Class